Create-Notification-Alert-using-NotificationManager-Android
===========================================================

Main objective of this tutorial is to create Notification Alerts with the use of NotificationManager. Notification is located at Title bar of the activity when notification is arrives.

You can find complete tutorial on how to use this code repo here : <a target="_blank" href="http://www.theappguruz.com/blog/create-notification-alert-using-notificationmanager-android">Create Notification Alert using NotificationManager | Android</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/mobile-application-development/">Mobile Application Development Company in India</a>
